from django.test import TestCase

# Create your tests here.

# Test Cases are written in the test.py file inside the blog folder. 
